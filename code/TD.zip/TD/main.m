clear all;
close all;
clc;

% K-order, rank-R tensor of dimensions D1>=D2>=...>=D_K, and R<=D2.
K = 5;
R = 4;
D = R+1+1:R+1+K;
[X,U] = KRDtensor(K,R,D);

% Compute its Canonical Polyadic Decomposition (CPD)
tic;
Uhat = CPD(X);
toc

% Compute the error.
Xhat = U2tensor(Uhat);
err = reshape(Xhat-X,[],1);
norm(err,Inf)