function X = U2tensor(U)
% ====================================================================
% Returns the low-rank tensor determined by U as in eqn (1) in
%
%   D. Pimentel-Alarcon,
%   A Simpler Approach to Low-Rank Tensor Canonical Polyadic Decomposition
%   2016
%
%
% Input:
%   
%   U = K matrices, each of size D(k) x R, containing the CPD of X.
%
% Output:
%
%   X = K-order, rank-R tensor determined by U as in eqn (1).
%
%
% Written by: Daniel Pimentel-Alarcon
% email: pimentelalar@wisc.edu
% Created: 2016
% ====================================================================

K = length(U);
R = size(U{1},2);
D = zeros(1,K);
for k=1:K,
    D(k) = size(U{k},1);
end
X = 0;
for r=1:R,
    Xr = U{1}(:,r);
    for k=2:K,
        Xr = kron(U{k}(:,r)',Xr);
    end
    Xr = reshape(Xr,D);
    X = X+Xr;
end