function Uhat = CPD(X)
% ====================================================================
% Receives a low-rank tensor X and computes its canonical polyadic
% decomposition (CPD) using the method in
%
%   D. Pimentel-Alarcon,
%   A Simpler Approach to Low-Rank Tensor Canonical Polyadic Decomposition,
%   Allerton, 2016
%
%
% Input:
%   
%   X = K-order, rank-R tensor with dimensions D1>=D2>=...>=D_K, and R<=D2.
%
% Output:
%
%   Uhat = K matrices, each of size D_k x R, containing the CPD of X.
%
%
% Written by: Daniel Pimentel-Alarcon
% email: pimentelalar@wisc.edu
% Created: 2016
% ====================================================================

D = size(X);
K = length(D);
R = rank(X(:,:,1));
Uhat = cell(K,1);

% PART 1: Obtain Uhat{1}
Utilde = X(:,1:R,1);
X22 = X(:,1:R,2);
Theta22 = (Utilde'*Utilde)\Utilde'*X22;
[Gamma,~] = eig(Theta22);
Uhat{1} =  Utilde*Gamma;

% PART 2: Obtain Uhat{k}, k=2,3,...,K.
P = (Uhat{1}'*Uhat{1})\Uhat{1}';
for k=2:K,
    Dk = 2:K;
    Dk(k-1) = [];
    Dk = [1,k,Dk];
    Xk = permute(X,Dk);
    Xk = Xk(:,:,1);
    Uhat{k} = (P*Xk)';
end

% PART 3: Obtain scaling factors lambda_r, r=1,2,...,R.
x = X(:,1);
theta = P*x;
u = zeros(K-1,R);
for k=1:K-1,
    u(k,:) = Uhat{k+1}(1,:);
end
u = prod(u);
lambda = theta./u';

Uhat{1} = Uhat{1}*diag(lambda);







