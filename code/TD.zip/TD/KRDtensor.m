function [X,U] = KRDtensor(K,R,D)
% ====================================================================
% Returns a generic K-order, R-rank tensor X of dimensions
% D(1)xD(2)x...xD(3) and its Canonical Polyadic Decomposition (CPD) U, as
% in eqn (1) in
%
%   D. Pimentel-Alarcon,
%   A Simpler Approach to Low-Rank Tensor Canonical Polyadic Decomposition
%   2016
%
%
% Input:
%   
%   K = order of the tensor.
%   R = rank of the tensor.
%   D = vector with the K dimensions of the tensor.
%
% Output:
%
%   X = K-order, rank-R tensor determined by U as in eqn (1).
%   U = K matrices, each of size D_k x R, containing the CPD of X.
%
%
% Written by: Daniel Pimentel-Alarcon
% email: pimentelalar@wisc.edu
% Created: 2016
% ====================================================================

U = cell(K,1);
for k=1:K,
    U{k} = randn(D(k),R);
end

X = 0;
for r=1:R,
    Xr = U{1}(:,r);
    for k=2:K,
        Xr = kron(U{k}(:,r)',Xr);
    end
    Xr = reshape(Xr,D);
    X = X+Xr;
end