function answer = checkThmCondition(Omega_breve)
% ====================================================================
% Determines whether Omega_breve contains a matrix Omega_hat with d-r
% columns satisfying the conditions of Theorem 3 (which is a generalization
% of Theorem 1) in:
%
%   Deterministic Conditions for Subspace Identifiability from Incomplete Sampling
%   D. Pimentel-Alarcon, N. Boston, R. Nowak, ISIT, 2015.
% 
% Input:
%   
%   Omega_breve = samping matrix with exactly r+1 nonzeros per column.
%
% Output:
%
%   resp = 1 if Omega satisfies (i), 0 otherwise.
%
%
% Written by: Daniel Pimentel
% email: pimentelalar@wisc.edu
% Created: 2017
% =====================================================================


% Obtain dimensions of the problem based on the sampling of Omega_breve
[d,N] = size(Omega_breve);
r = length(find(Omega_breve(:,1)))-1;

% Draw U randomly
U = randn(d,r);

% Construct A
A = zeros(d,d-r+1);
for i=1:N,
    omega_i = find(Omega_breve(:,i));
    U_omega_i = U(omega_i,:);
    a_omega_i = null(U_omega_i');
    a_i = zeros(d,1);
    a_i(omega_i) = a_omega_i;
    A(:,i) = a_i;
end

% Check whether dim ker A'=r.
if rank(A) == d-r,
    answer = 1;
else
    answer = 0;
end




