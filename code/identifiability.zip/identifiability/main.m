% ====================================================================
% Toy examples to determine whether a sampling matrix Omega satisfies the
% subspace identifiability conditions of Theorem 3 (which is a
% generalization of Theorem 1) in:
%
%   Deterministic Conditions for Subspace Identifiability from Incomplete Sampling
%   D. Pimentel-Alarcon, N. Boston, R. Nowak, ISIT, 2015.
%
%
% Written by: Daniel Pimentel
% email: pimentelalar@wisc.edu
% Created: 2017
% =====================================================================

clear all; close all; clc;
r = 2;

% ===== Example 1 =====
Omega = [
    1 1 1 1 0;
    1 1 1 0 1;
    1 1 0 1 1;
    1 0 1 1 1;
    0 1 1 1 1];

Omega_breve = split(Omega,r)
answer = checkThmCondition(Omega_breve)

% ===== Example 2 =====
Omega = [
    1 0;
    1 0;
    1 0;
    1 0;
    1 1;
    0 1;
    0 1;
    0 1];

Omega_breve = split(Omega,r)
answer = checkThmCondition(Omega_breve)

% ===== Example 3 =====
Omega = [
    1 0;
    1 0;
    1 0;
    1 1;
    1 1;
    0 1;
    0 1;
    0 1];

Omega_breve = split(Omega,r)
answer = checkThmCondition(Omega_breve)

% ===== Example 4 (counterexample in the proof of Corollary 4) =====
Omega = [
    1 1 0 0 0 0 0 0;
    1 1 1 0 0 1 0 0;
    0 1 1 0 0 0 1 0;
    1 0 1 0 0 0 0 1;
    0 0 0 1 0 1 0 0;
    0 0 0 1 0 0 1 0;
    0 0 0 1 0 0 0 1;
    0 0 0 0 1 1 0 0;
    0 0 0 0 1 0 1 0
    0 0 0 0 1 0 0 1];

Omega_breve = split(Omega,r)
answer = checkThmCondition(Omega_breve)


