function Omega_breve = split(Omega,r)
% ====================================================================
% Splits a sampling matrix Omega (with r+1 or more nonzeros per column)
% into the matrix Omega_breve (with exactly r+1 nonzeros per column) as
% described in the Appendix of:
%
%   Deterministic Conditions for Subspace Identifiability from Incomplete Sampling
%   D. Pimentel-Alarcon, N. Boston, R. Nowak, ISIT, 2015.
% 
% Input:
%   
%   Omega = samping matrix with r+1 or more nonzeros per column.
%
% Output:
%
%   Omega_breve = "equivalent" matrix with exactly r+1 nonzeros per column.
%
%
% Written by: Daniel Pimentel
% email: pimentelalar@wisc.edu
% Created: 2017
% =====================================================================

[d,N] = size(Omega);
N_breve = sum(sum(Omega)) - r*N;    % Number of columns in Omega_breve
Omega_breve = zeros(d,N_breve);

n = 0;
for i=1:N,
    omega_i = find(Omega(:,i));
    L_i = length(omega_i);
    Omega_i = zeros(d,L_i-r);
    for ell = 1 : L_i-r,
        Omega_i([omega_i(1:r);omega_i(r+ell)],ell) = 1;
    end
    Omega_breve(:,n+1:n+L_i-r) = Omega_i;
    n = n + L_i-r;
end