function h = EM(XO,K,r,params)
% =========================== EM Algorithm ===========================
% Finds a set of K, r-dimensional subspaces that best fit the
% incomplete data matrix XO using the EM algorithm in:
%
%   D. Pimentel, L. Balzano, R. Nowak
%   On the Sample Complexity of Subspace Clustering with Missing Data
%   IEEE Statistical Signal Processing, 2014.
% 
% Inputs:
%   
%   XO = dxN matrix.  Zeros correspond to missing entries.
%
%   K = number of subspaces.
%
%   r = dimension of the subspaces.
%
%   params = vector containing [tol, maxIter, noisy, rhoKnown].
%       tol = tolerance level to indicate convergence.
%       maxIter = maximum number of iterations.
%       noisy = binary variable indicating whether
%               to estimate the noise level.
%           1 = estimate.
%           0 = do not estimate.
%       rhoKnown = binary variable indicating whether
%                  the proportion of points in each 
%                  subspace is known.
%           1 = proportion of points is known; do not estimate.
%           0 = proportion of points is unknown; estimate.
%
% Output: h = structure containing:
%   h.W = Cell array containing the bases of each estimated subspace.
%
%   h.Z = Clustering.
%
%   h.s2 = vector containing the estimate of the 
%          noise level in each subspace.
%
%   h.Rho = vector containing the proportion of points in each subspace.
%
%   h.X = Estimate of the completed columns.
%
%
% Written by: Daniel Pimentel-Alarcon
% email: pimentelalar@wisc.edu
% Created: 2013
% =====================================================================

tol = params(1);
maxIter = params(2);
noisy = params(3);
rhoKnown = params(4);

% == Initialize estimates ==
h = initializeh(XO,K,r,tol,noisy,rhoKnown);

dif = tol + 1;
it = 0;
% =========================== Run EM ===========================
while it < maxIter && dif >= tol
    it = it+1;
    
    % Keep track of our previous estimates to check for convergence
    prevX = h.X;
    
    % Run EM
    [PL,E] = Estep(XO,h);
    h = Mstep(PL,E,h);
    
    % ===== Find difference as convergence criteria =====
    dif = norm(prevX-h.X)./norm(h.X);
    
end

end

function [PL,E] = Estep(XO,h)
% ============================ E-step ============================

PL = PosteriorLikelihood(XO,h);
E = Expectations(XO,h);
end

function E = Expectations(XO,h)
% =============== Find E[x], E[yy'], E[xy'] and E[xx'] ===============

E = struct();
E.Y = cell(h.N,h.K);
E.X = cell(h.N,h.K);
E.YY = cell(h.N,h.K);
E.XY = cell(h.N,h.K);
E.XX = cell(h.N,h.K);

for i=1:h.N,
    idxO = h.Idx.O{i};
    idxM = h.Idx.M{i};
    xio = XO(idxO,i);
    for k=1:h.K,
        hWk = h.W{k};
        hWkOi = hWk(idxO,:);
        hWkMi = hWk(idxM,:);
        
        E.Y{i,k} = zeros(h.r,1);
        E.X{i,k} = zeros(h.d,1);
        
        E.Y{i,k} = (hWkOi'*hWkOi + h.s2(k)*eye(h.r))\hWkOi'*xio;
        E.X{i,k}(idxO) = xio;
        E.X{i,k}(idxM) = hWkMi*E.Y{i,k};
        
        % Find cov(y), cov(x^m,y) to later find E[yy]] and E[xm y']
        covXmY = h.s2(k)*hWkMi/(hWkOi'*hWkOi + h.s2(k)*eye(h.r));
        
        E.YY{i,k} = h.s2(k)*eye(h.r)/(hWkOi'*hWkOi + h.s2(k)*eye(h.r)) + E.Y{i,k}*E.Y{i,k}';
        E.XY{i,k}(idxO,:) = xio*E.Y{i,k}';
        E.XY{i,k}(idxM,:) = covXmY + E.X{i,k}(idxM) * E.Y{i,k}';
        
        if h.noisy == 1
            % In the noisy case also find cov(x^m) to later find E.XX
            covXm = h.s2(k)*eye(length(idxM)) + covXmY*hWkMi';
            
            E.XX{i,k}(idxO,idxO) = xio*xio';
            E.XX{i,k}(idxO,idxM) = xio*E.X{i,k}(idxM)';
            E.XX{i,k}(idxM,idxO) = E.XX{i,k}(idxO,idxM)';
            E.XX{i,k}(idxM,idxM) = covXm + E.X{i,k}(idxM)*E.X{i,k}(idxM)';
        end
        
    end
end

end

function W=farthestW(X,nc,cc)
% nn farthest insertion subspace initialization
% Written by Laura Balzano

no=sum(X.^2);
[dim N]=size(X);
rid=ceil(N*rand);
buf=5;
W = cell(1,nc);
for k=1:nc
    x=X(:,rid);
    sX=X-diag(x)*ones(dim,N);
    dd=sum(sX.^2);
    [td tdi]=sort(dd);
    [uu ss vv]=svd(X(:,tdi(1:cc+buf)),'econ');    
    W{k}=uu(:,1:cc);    
    md(:,k)=no-sum((W{k}'*X).^2);
    tmd=min(md,[],2);
    tmd=tmd/sum(tmd);
    
    rid=samplefromd(tmd);
end

end

function id=samplefromd(d)
% samples from density d
% Written by Laura Balzano
u=cumsum(d);
tu=u-rand;
tu(find(tu<0))=inf;
[ju id]=min(tu);

end

function p = gausspdf(x,mu,C)
% ================ Gaussian probability density function ================

p = exp(-1/2*(x-mu)'/C*(x-mu))/sqrt(abs(det(C)))/((2*pi)^(length(x)/2));
if isnan(p)
    p = 0;
end
end

function Idx = indices(XO)
% == Determine indices of the observed and unobserved entries ==

N = size(XO,2);

Idx = struct();
Idx.O = cell(N,1);
Idx.M = cell(N,1);
for i=1:N,
    Idx.O{i} = find(XO(:,i)~=0);
    Idx.M{i} = find(XO(:,i)==0);
end
end

function h = initializeh(XO,K,r,s2,noisy,rhoKnown)
% ===================== Initialize parameters =====================

h = struct();
[h.d,h.N] = size(XO);
h.K = K;
h.r = r;

h.X = XO;
h.W = farthestW(XO,K,r);
h.Rho = 1/K * ones(1,K);
h.s2 = s2*ones(1,K);

% == Indices of observed entries ==
h.Idx = indices(XO);

h.noisy = noisy;
h.rhoKnown = rhoKnown;
end

function h = Mstep(PL,E,h)
% ============================ M-step ============================

% ===== Find our new h.W
h.W = cell(1,h.K);
for k=1:h.K,
    num = 0;
    den = 0;
    for i=1:h.N,
        num = num + PL(i,k)*E.XY{i,k};
        den = den + PL(i,k)*E.YY{i,k};
    end
    h.W{k} = num/den;
end


% ====== Cluster
[~,h.Z] = max(PL,[],2);

% ====== Find our new h.X
h.X = zeros(h.d,h.N);
for i=1:h.N,
    h.X(:,i) = E.X{i,h.Z(i)};
end

% ====== Find our new h.Rho
if h.rhoKnown==0
    h.Rho = mean(PL);
end

% ====== Find our new s2
if h.noisy==1
    % Auxiliary variables
    traceXX = zeros(1,h.K);
    traceYX = zeros(1,h.K);
    traceYY = zeros(1,h.K);
    
    % Find our new estimate of s2
    for k=1:h.K,
        for i=1:h.N,
            traceXX(k) = traceXX(k) + trace(PL(i,k)*E.XX{i,k});
            traceYX(k) = traceYX(k) + trace(PL(i,k)*E.XY{i,k}'*h.W{k});
            traceYY(k) = traceYY(k) + trace(PL(i,k)*E.YY{i,k}*h.W{k}'*h.W{k});
        end
        h.s2(k) = (traceXX(k)-2*traceYX(k)+traceYY(k))/(h.d*sum(PL(:,k)));
    end
end

end

function PL = PosteriorLikelihood(XO,h)
% == Find new Posterior Likelihood according to the new parameters h ==

PL = zeros(h.N,h.K);
for i=1:h.N,
    idxO = h.Idx.O{i};
    xio = XO(idxO,i);
    for k=1:h.K,
        hWk = h.W{k};
        hWkOi = hWk(idxO,:);
        hCkOi = hWkOi*hWkOi' + h.s2(k)*eye(length(idxO));
        PL(i,k) = gausspdf(xio,0,hCkOi);
    end
    if sum(PL(i,:))==Inf
        PL(i,:) = PL(i,:)==Inf;
    end
    if sum(PL(i,:))==0,
        PL(i,:) = 1;
    end
    PL(i,:) = PL(i,:).*h.Rho;
    PL(i,:) = PL(i,:)/sum(PL(i,:));
end

end




