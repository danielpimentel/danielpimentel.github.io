function c = correspondence(What,W)

K = length(What);
Residuals = zeros(K);

for k1=1:K,
    for k2=1:K,
        Residuals(k1,k2) = norm(What{k1}-Projection(What{k1},W{k2}))/norm(W{k2});
    end
end

[~,c] = min(Residuals);
end

function hX = Projection(X,W)
% ========= Projection of X onto the subspace spanned by W =========

hX = W/(W'*W)*W'*X;

end