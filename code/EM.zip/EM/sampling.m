function Omega = sampling(d,N,ell)
Omega = zeros(d,N);
for i=1:N,
    Omega(randsample(d,ell),i) = 1;
end
end