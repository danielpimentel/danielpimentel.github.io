function [X,W,Z] = gendata(d,r,K,Nk,s2)
% ================ generate synthetic data ================
W = cell(1,K);
Z = zeros(K*Nk,1);
for k=1:K,
    W{k} = orth(randn(d,r));
    Yk = randn(r,Nk);
    Xk = W{k}*Yk + s2*randn(d,Nk);
    X(:,(k-1)*Nk+1:k*Nk) = Xk;
    Z((k-1)*Nk+1:k*Nk) = k;
end
end

