clear all; clc;
rand('state',sum(100*clock));
%==================== Setup
d = 25;                 %Ambient dimension (# of rows)
r = 5;                  %Dimension of each subspace
K = 5;                  %Number of subspaces
Nk = 50;                %Columns per subspace
ell = 20;               %Observed entries per column
s2 = 1e-2;              %Noise level
params = [1e-3,d,0,1];  %Parameters of EM

%==================== Generate data
[X,W,Z] = gendata(d,r,K,Nk,s2);

%==================== Sampling pattern
Omega = sampling(d,K*Nk,ell);

%==================== Subsample matrix
XO = X.*Omega;

%==================== Run EM
fprintf('Running EM \n');
h = EM(XO,K,r,params);

%==================== Results
c = correspondence(h.W,W);
err = mean(h.Z~=c(Z)');


