function Uhat = recoverSubspace(YO)
% ====================================================================
% Estimates the r-dimensional subspace that fits the
% dxN, noisy, rank-r matrix YO that has been sampled 
% adaptively according to the ALARCON algorithm in
%
%   D. Pimentel, R. Nowak
%   Adaptive Strategy for Restricted-Sampling
%   Noisy Low-Rank Matrix Completion
%   IEEE CAMSAP, 2015
% 
% Input:
%   
%   YO = dxN, rank-r matrix sampled adaptively according to
%       ALARCON Algorithm.  Zeros correspond to missing entries.
%
% Output:
%
%   Uhat = dxr basis of the r-dimensional subspace that fits YO.
%
%
% Written by: Daniel Pimentel
% email: pimentelalar@wisc.edu
% Created: 2015
% =====================================================================


%Obtain dimensions of the problem based on the sampling of YO
[d,N] = size(YO);
r = length(find(YO(:,1)))-1;
Ni = N/(d-r);

%Recover Uhat according to ALARCON
A = zeros(d,d-r);
for i=1:d-r,
    oi = find(YO(:,(i-1)*Ni+1));
    Yoi = YO(oi,(i-1)*Ni+1:i*Ni);
    [Uoi,~,~] = svd(Yoi*Yoi');
    aoi = Uoi(:,r+1);
    ai = zeros(d,1);
    ai(oi) = aoi;
    A(:,i) = ai;
end
Uhat = null(A');




