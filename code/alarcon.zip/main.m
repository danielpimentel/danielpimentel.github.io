clear all; clc;
rand('state',sum(100*clock));

% General setup
d = 100;            % Ambient dimension
r = 10;             % Rank
Ni = 2*r;           % Columns per block
sigma = 1e-8;       % Noise level

% Sampling matrix satisfying C1
Omega = [ones(r,d-r);eye(d-r)];

% Sampling part of ALARCON
[YO,X] = sampling(Omega,Ni,sigma);

% Recovery part of ALARCON
Uhat = recoverSubspace(YO);
Bhat = Uhat /(Uhat(1:r,:)'*Uhat(1:r,:))*Uhat(1:r,:)';
Xhat = Bhat*YO(1:r,:);

% Error
Error = norm(Xhat-X,'fro')