function [YO,X] = sampling(Omega,Ni,sigma)
% Generates a dxNi(d-r), rank-r, noisy matrix, observed
% on (d-r) blocks of size (r+1)xNi according to the sampling Omega
% satisfying condition C1 in
% 
%   D. Pimentel, R. Nowak
%   Adaptive Strategy for Restricted-Sampling
%   Noisy Low-Rank Matrix Completion
%   IEEE CAMSAP, 2015
% 
% Inputs:
%   
%   Omega = dx(d-r) sampling matrix satisfying condition C1.
%
%   Ni = Number of columns of Y that will be sampled per column of Omega.
%
%   sigma = Noise level.
%
% Outputs:
%
%   YO = Noisy matrix sampled according to Omega
%
%   X = Noiseless, unit-norm, rank-r matrix (ground truth).
%
%
% Written by: Daniel Pimentel
% email: pimentelalar@wisc.edu
% Created: 2015
% =====================================================================

% Recover the dimensions of the problem based on the sampling in Omega
[d,dr] = size(Omega);
r = d-dr;

% Generate noiseless, rank-r matrix
U = randn(d,r);
X = U*randn(r,Ni*(d-r));
X = X/norm(X);

%Generate noisy matrix
Y = X + sigma*randn(d,Ni*(d-r));

%Sample Y according to Omega
YO = zeros(d,Ni*(d-r));
for i=1:d-r,
    oi = find(Omega(:,i));
    YO(oi,(i-1)*Ni+1:i*Ni) = Y(oi,(i-1)*Ni+1:i*Ni);
end







