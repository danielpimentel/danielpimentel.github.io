clear all; clc;
rand('state',sum(100*clock));

% General setup
d = 11;            % Ambient dimension
r = 3;             % Rank

% ============== Sampling matrix satisfying (i) ==============
goodOmega = tril(ones(d,d-r+1))-tril(ones(d,d-r+1),-r-1) ...
    + triu(ones(d,d-r+1),d-r);

% Verify whether Omega satisfies (i)
resp = checkOmega(goodOmega)

% ============== Sampling matrix NOT satisfying (i) ==============
badOmega = [ones(r,d-r);eye(d-r)];
extraCol = [1;zeros(d-r-1,1);ones(r,1)];
badOmega = [badOmega extraCol];

% Verify whether Omega satisfies (i)
resp = checkOmega(badOmega)