function resp = checkOmega(Omega)
% ====================================================================
% Determines whether a matrix Omega satisfies condition (i) in
%
%   D. Pimentel, R. Nowak
%   The Sample Complexity of Subspace Clustering with Missing Data.
% 
% Input:
%   
%   Omega = dx(d-r+1) matrix with r+1 nonzero entries per column.
%
% Output:
%
%   resp = 1 if Omega satisfies (i), 0 otherwise.
%
%
% Written by: Daniel Pimentel
% email: pimentelalar@wisc.edu
% Created: 2015
% =====================================================================


% Obtain dimensions of the problem based on the sampling of YO
d = size(Omega,1);
r = length(find(Omega(:,1)))-1;

% Draw U randomly
U = randn(d,r);

% Construct A
A = zeros(d,d-r+1);
for i=1:d-r+1,
    oi = find(Omega(:,i));
    Uoi = U(oi,:);
    aoi = null(Uoi');
    ai = zeros(d,1);
    ai(oi) = aoi;
    A(:,i) = ai;
end



% Check whether dim ker Ai'=r for every i.
resp = 1;
for i=1:d-r+1,
    Ai = A;
    Ai(:,i) = [];
    if rank(Ai)<d-r,
        resp = 0;
    end
end




